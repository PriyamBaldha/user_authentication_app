class Global {
  static String? name;
  static String? number;
  static String? email;
  static String? password;
}
